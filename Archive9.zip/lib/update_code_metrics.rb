class UpdateCodeMetrics < Struct.new(:record, :url)

  def update
    # api = CodeClimateApi.new(CodeClimateUser.password_user)
  end
end