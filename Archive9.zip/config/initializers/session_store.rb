# Be sure to restart your server when you modify this file.

LighthouseDb::Application.config.session_store :cookie_store, key: '_lighthouse_db_session'
